# Avaliação: Gestão de contratos imobiliários

## Problema

Você precisa criar uma aplicação MM4 e MM5 para a gestão de contratos de imóveis, compreendendo toda a parte operacional de criação, consultas, atualização e exclusão de contratos de imóveis.

As user stories disponibilizadas pelos times de negócio e qualidade são as seguintes:

```gherkin
US1 - Inclusão de novo contrato imobiliário

Como um analista financeiro
Eu quero incluir um novo contrato informando número do contrato, data da assinatura, nome do cliente, data de nascimento, agencia, tipo de imóvel, valor do imóvel e CNPJ do fiador
Para que o sistema mantenha um cadastro oficial e padronizado dos contratos de imóveis

Regras
    [R01] A inclusão deve receber os seguintes campos de maneira obrigatória:
        - Número do contrato
        - Data da assinatura
        - Nome do cliente
        - Número da agência
        - Data da nascimento
        - Tipo do imóvel
        - Valor do imóvel
        - CNPJ do fiador
    [R02] O número do contrato deve conter exatamente 7 dígitos numéricos de 1000000 a 9999999
    [R03] A data da assinatura deve ser preenchida com uma data
    [R04] O nome do cliente deve conter até 35 caracteres
    [R05] O número da agência deve conter exatamente 4 dígitos numéricos de 1000 a 9999
    [R06] A data da nascimento deve ser a data de nascimento do cliente
    [R07] O tipo do imóvel deve aceitar apenas 'C', 'A', 'T' ou 'P'
    [R08] O valor do imóvel deve ser maior que 0 (zero)
    [R09] O CNPJ do fiador deve ser válido perante cálculos de dígito verificador
    [R10] A data de última atualização deve ser sempre preenchida com a data data/hora atual no momento da inclusão

Critérios de Aceitação
    [CA01] Dado que informo um número do contrato válido, data da assinatura válida, nome do cliente válido, data de nascimento válida, agencia válida, tipo de imóvel válido, valor do imóvel válido e CNPJ do fiador válido, sendo que não existe na base de dados um contrato com o mesmo número, então a aplicação inclui o novo contrato com a data de atualização com a data/hora atuais
    [CA02] Dado que o número do contrato não é informado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de contrato deve ser informado (entre 1000000 e 9999999)."
    [CA03] Dado que o número do contrato está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de contrato deve ser informado (entre 1000000 e 9999999)."
    [CA04] Dado que o nome do cliente não é informado, então a aplicação rejeita a inclusão com a mensagem "Um nome válido de cliente deve ser informado (máximo de 35 caracteres)."
    [CA05] Dado que o nome do cliente maior do que o esperado, então a aplicação rejeita a inclusão com a mensagem "Um nome válido de cliente deve ser informado (máximo de 35 caracteres)."
    [CA06] Dado que o número da agência não é informado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [CA07] Dado que o número da agência está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [CA08] Dado que a data da nascimento não é informada, então a aplicação rejeita a inclusão com a mensagem "Uma data de nascimento deve ser informada."
    [CA09] Dado que o tipo de imóvel não é informado, então a aplicação rejeita a inclusão com a mensagem "Um tipo de imóvel válido deve ser informado 'C', 'A', 'T' ou 'P'."
    [CA10] Dado que o tipo de imóvel informado é diferente das opções possíveis, então a aplicação rejeita a inclusão com a mensagem "Um tipo de imóvel válido deve ser informado 'C', 'A', 'T' ou 'P'."
    [CA11] Dado que o valor do imóvel não é informado, então a aplicação rejeita a inclusão com a mensagem "Um valor válido de imóvel deve ser informado (maior que zero)."
    [CA12] Dado que o valor do imóvel está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um valor válido de imóvel deve ser informado (maior que zero)."
    [CA13] Dado que o CNPJ não é informado, então a aplicação rejeita a inclusão com a mensagem "Um CNPJ válido deve ser informado."
    [CA14] Dado que o CNPJ informado é inválido (referente aos cálculos de dígito verificador de CNPJ), então a aplicação rejeita a inclusão com a mensagem "Um CNPJ válido deve ser informado."
    [CA15] Dado que já existe um contrato com o mesmo número de contrato, então a aplicação rejeita a inclusão com a mensagem "Já existe na base de dados um contrato com o número de contrato informados."
```

```gherkin
US2 - Listagem de contratos imobiliários

Como um gerente de agência
Eu quero visualizar a lista completa de contratos cadastrados
Para apoiar consultas operacionais, análises financeiras e auditorias internas

Regras
    [R01] A listagem deve retornar os contratos cadastrados de acordo com os critérios de filtragem (todos opcionais), que podem ser uma composição de:
        - Data da assinatura
        - Tipo do imóvel
        - Nome do cliente
    [R02] O tipo do imóvel deve aceitar apenas 'C', 'A', 'T' ou 'P'
    [R03] O nome do cliente deve conter até 35 caracteres
    [R04] A listagem deve exibir para cada contrato:
        - Número do contrato
        - Data da assinatura
        - Nome do cliente
        - Número agência
        - Data de nascimento
        - Tipo de imóvel
        - Valor do imóvel
        - CNPJ do fiador
        - Data/hora da última atualização

Critérios de Aceitação
    [CA01] Dado que solicito a listagem sem nenhum critério de filtragem informado, se houver contratos cadastrados, então a aplicação retorna todas os contratos cadastrados com as informações esperadas
    [CA02] Dado que solicito a listagem com um set de critérios informado, se houver contratos cadastrados para os critérios informados, então a aplicação retorna os devidos contratos cadastrados com as informações esperadas
    [CA03] Dado que o tipo de imóvel informado é diferente das opções possíveis, então a aplicação rejeita a inclusão com a mensagem "Um tipo de imóvel válido deve ser informado 'C', 'A', 'T' ou 'P'."
    [CA04] Dado que o nome do cliente maior do que o esperado, então a aplicação rejeita a inclusão com a mensagem "Um nome válido de cliente deve ser informado (máximo de 35 caracteres)."
    [CA05] Dado que solicito a listagem com ou sem critérios de filtragem informados e não há contratos cadastrados para satisfazer a busca, então a aplicação rejeita a consulta com a mensagem "Nenhum registro encontrado."
```

```gherkin
US3 - Consulta de contrato imobiliário

Como um gerente de agência
Eu quero consultar os dados completos de um contrato específico
Para validar informações em operações internas, auditorias e conferências periódicas de dados

Regras
    [R01] A consulta deve ser realizada exclusivamente pelo critério de filtragem obrigatório de:
        - Número do contrato
    [R02] O número do contrato deve conter exatamente 7 dígitos numéricos de 1000000 a 9999999
    [R03] A consulta deve exibir para o contrato:
        - Número do contrato
        - Nome do cliente
        - Número agência
        - Data de nascimento
        - Data de assinatura
        - Tipo de imóvel
        - Valor do imóvel
        - CNPJ do fiador
        - Data/hora da última atualização

Critérios de Aceitação
    [CA01] Dado que informo um número do contrato válido, e existe na base de dados um contrato correspondente, então a aplicação retorna os dados completos do contrato com as informações esperadas
    [CA02] Dado que o número do contrato não é informado, então a aplicação rejeita a consulta com a mensagem "Um número válido de contrato deve ser informado (entre 1000000 e 9999999)."
    [CA03] Dado que o número do contrato está fora do intervalo numérico esperado, então a aplicação rejeita a consulta com a mensagem "Um número válido de contrato deve ser informado (entre 1000000 e 9999999)."
    [CA04] Dado que não existe um contrato com o número informado, então a aplicação rejeita a consulta com a mensagem "Não existe um contrato cadastrado para o critério informado."
```

```gherkin
US4 - Alteração de CNPJ do fiador de um contrato imobiliário

Como um analista financeiro
Eu quero alterar o CNPJ do fiador de um contrato específico
Para manter o cadastro atualizado quando há mudança de empresa fiadora do imóvel

Regras
    [R01] A alteração deve ser realizada exclusivamente pelo critério de filtragem obrigatório de:
        - Número do contrato
    [R02] O número do contrato deve conter exatamente 7 dígitos numéricos de 1000000 a 9999999
    [R03] O CNPJ do fiador deve ser o único campo permitido alterar    
    [R04] O CNPJ do fiador deve ser válido perante cálculos de dígito verificador
    [R05] A data de última atualização deve ser sempre atualizada com a data data/hora atual no momento da alteração

Critérios de Aceitação
    [CA01] Dado que informo um número de contrato válido e um CNPJ do fiador válido, e existe na base de dados um contrato correspondente, então a aplicação altera o CNPJ e a data de atualização com a data/hora atuais. Após concluída a alteração, deverá haver um redirecionamento para a listagem
    [CA02] Dado que o número do contrato não é informado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de contrato deve ser informado (entre 1000000 e 9999999)."
    [CA03] Dado que o número do contrato está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de contrato deve ser informado (entre 1000000 e 9999999)."
    [CA04] Dado que o CNPJ não é informado, então a aplicação rejeita a inclusão com a mensagem "Um CNPJ válido deve ser informado."
    [CA05] Dado que o CNPJ informado é inválido (referente aos cálculos de dígito verificador de CNPJ), então a aplicação rejeita a inclusão com a mensagem "Um CNPJ válido deve ser informado."
    [CA06] Dado que não existe um contrato com o mesmo número de contrato informado, então a aplicação rejeita a alteração com a mensagem "Não existe um contrato cadastrado para o critério informado."
```

## Estrutura de dados

Modelagem já efetuada e pronta no **IBM DB2**:

```sql
SELECT
    NUMERO_CONTRATO -- DECIMAL(7,0)   NN PK
  , DATA_ASSINATURA -- DATE           NN
  , NOME_CLIENTE    -- CHAR(35)       NN
  , AGENCIA         -- CHAR(4)        NN
  , DATA_NASCIMENTO -- DATE           NN
  , TIPO_IMOVEL     -- CHAR(1)        
  , VALOR_IMOVEL    -- DECIMAL(15,2)    
  , CNPJ            -- DECIMAL(14,0)  NN
  , ULT_ATUALIZACAO -- TIMESTAMP      NN
FROM PXC.CONTRATO;
```

## Informações adicionais
- A convenção é que as mensagens dos CAs devem ficar no MM4
- Além da operação _Excluir_ , a operação _Imprimir_ também **não precisa ser desenvolvida**;
- O _identificador curto para o TO_ de contratos é **"ct"**;
- O _produto_ preenchido durante a geração da tela é **Treinamento MM5**;
- Lembre-se de gerar também o **projeto de processamento de telas** para a solução;
- O objeto `oInfra.getUtil()` fornece métodos que podem ser de grande utilidade (como por exemplo para manipular máscaras, obter valores de campos mais complexos, entre outros)
  
## Objetivos
- Criação do projeto de **TOs**
  - Deve tratar corretamente o mapeamento do _enum_ para tipo de imóvel do contrato
- Criação do projeto de **camada Q:**
  - Deve conter o controle por _alias_
  - Deve conter o controle de _SAC_
- Criação do projeto de **camada S:**
  - A interface pública deve obrigatoriamente fazer uso dos métodos gerados pelo **Gerador de Classes MM4** para cada uma das operações respectivas às user stories — métodos com nomes diferentes dos originais serão desconsiderados na correção
  - Todas as regras contidas nas user stories devem ser satisfeitas
  - Deve conter o objeto de mapa de mensagens
  - Deve retornar para os devidos cenários, **mensagens idênticas** às definidas nos critérios de aceitação das user stories
- Criação do projeto de **camada U:**
  - Todos os critérios de aceitação contidos nas user stories devem ser atendidos por testes (não é necessária a entrega de casos de teste)
    - No nome do teste deve constar o identificador da user story e do critério de aceitação que ele cobre (exemplos: `US1_CA01_IncluirContratoComSucessoTest`, `US3_CA05_ObterContratoComNumeroContratoInvalidoTest`, etc.)
  - As devidas mensagens retornadas da camada S devem ser validadas de acordo com os critérios de aceitação contidos nas user stories
  - Deve conter o objeto mock com ao menos 1 teste de falha ou exceção com dependência "mockada"
- Criação do **projeto de processamento de telas**
- Criação do projeto de **camada W:**
  - Deve possuir as telas de **Filtro**, **Lista** e **Cadastro** (padrão 3 telas) com cada uma das telas exercendo sua função em face às user stories:
    - US1 - Inclusões via **Cadastro (inclusão)**
    - US2 - Uso da **Filtro** para carregar a **Lista**
    - US3 - Seleção de um item da **Lista** e carregamento bloqueado dos dados na **Cadastro (consulta)**
    - US4 - Desbloqueio e alterações via **Cadastro (alteração)**
  - Deve se comunicar com o backend fornecido e realizar de forma bem sucedida cada uma das operações respectivas às user stories
  - Todas as regras contidas nas user stories devem ser satisfeitas
  - Todos os critérios de aceitação contidos nas user stories devem ser satisfeitos conforme testes manuais
- É necessária a agregação dos dois novos projetos criados à **solução padrão** (arquivo .sln)

## Classe utilitária

Para esta avaliação, na pasta da aula foi disponibilizada uma classe utilitária contendo métodos e validadores reutilizáveis. Coloque-a **dentro do projeto de TOs** (`Pxcbtoxn`).
<!-- Utilitário em [./_assets/02-utilitario-avaliacao/] -->

Ela inclui funcionalidades de apoio como:

### BDUtils

- Constante `BD_CURRENT_TIMESTAMP` para auxiliar na implementação de SAC na **camada Q**. Em uma inclusão, por exemplo:
  
  ```csharp
  // Problema: Diferentes trechos de código usando a mesma string "CURRENT_TIMESTAMP" de forma duplicada e com margens para erro
  Sql.MontarCampoInsert(TOIdioma.DATA_HORA_ULTIMA_ALTERACAO); // ou Sql.MontarCampoInsert("DTHR_ULT_ATU");
  Sql.Temporario.Append("CURRENT_TIMESTAMP");
  
  // Solução: String centralizada em um só lugar e auxiliada pela tipagem forte
  Sql.MontarCampoInsert(TOIdioma.DATA_HORA_ULTIMA_ALTERACAO); // ou Sql.MontarCampoInsert("DTHR_ULT_ATU");
  Sql.Temporario.Append(BDUtils.BD_CURRENT_TIMESTAMP);
  ```

- Métodos `IsParametroPontoFlutuante(...)` e `FormatarParametroPontoFlutuante(...)` para auxiliar em uma configuração mais limpa de campos de valor monetário dentro do método `CriarParametro(...)` da **Camada Q**:
  
  ```csharp
  // Problema: Código de difícil compreensão e com regras sem muita explicação do porquê
  // [...]
  if (parametro.Scale > 0 && conteudo != null &&  parametro.DbType != DbType.DateTime)
  {
      parametro.Value = String.Format(CultureInfo.InvariantCulture, "{0:F" + parametro.Scale + "}", conteudo);
  }
  else
  {
      parametro.Value = conteudo;
  }
  // [...]

  // Solução: Mesma implementação, porém mais clara quanto à intenção (mais expressiva)
  // [...]
  if (BDUtils.IsParametroPontoFlutuante(parametro.DbType, parametro.Scale) && conteudo != null)
      parametro.Value = BDUtils.FormatarParametroPontoFlutuante(conteudo, parametro.Scale);
  else
      parametro.Value = conteudo;
  // [...]
  ```

### TOUtils

- Método `ExtrairMensagemAtributoValidacaoCampoTO<T>(...)` para auxiliar a pegar as mensagens de validação adicionadas via atributos de validação direto nos campos do TO, por exemplo:

  Para um dado campo do TO anotado com o atributo **NaoBranco** (nome de classe `NaoBrancoAttribute`):

  ```csharp
  // [...]
  [NaoBranco(mensagemErro: "Código ISO combinado deve ser informado.")]
  public CampoObrigatorio<string> CodigoIsoCombinado { get; set; }
  // [...]
  ```

  No momento do teste na camada U, essa mensagem que foi configurada no parâmetro `mensagemErro` pode ser recuperada para validar o resultado através de:

  ```csharp
  // [...]
  var mensagemNaoBrancoEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<NaoBrancoAttribute>(toIdioma, nameof(toIdioma.CodigoIsoCombinado));

  Assert.That(resultado.Mensagem.ParaUsuario, Contains.Substring(mensagemNaoBrancoEsperada)); // "Código ISO combinado deve ser informado."
  // [...]
  ```

### Validador combinado de CPF e CNPJ

- Atributo `CPFCNPJAttribute` para fazer a validação combinada de ambos os tipos de documento ao mesmo tempo para um dado campo:

  ```csharp
  // [...]
  [CPFCNPJ(mensagemErro: "Um CPF ou CNPJ válido deve ser informado para o identificador.")]
  public CampoObrigatorio<string> Identificador { get; set; }
  // [...]
  ```

> Notas:
>
> - Os trechos de código acima **são exemplos** — use-os como base para implementar na sua aplicação, conforme as regras e critérios de aceitação fornecidos;
> - O uso das funcionalidades de **BDUtils** e **TOUtils** é opcional — não haverão prejuízos de pontuação caso decida-se não utilizá-los (porém, para efeitos de aprendizado e clareza de código, recomendamos o uso).

## Protótipos de referência

Verifique estes prints de protótipos para referência visual da construção das telas:

### Filtro
#### - Filtro sem nada preenchido
![Filtro sem nada](./_assets/02-filtro-sem-nada.png)

#### - Filtro preenchido corretamente
![Filtro preenchido corretamente](./_assets/08-filtro-preenchido-corretamente.png)

#### - Filtro campo data
![Filtro campo data](./_assets/03-filtro-campo-data.png)

#### - Filtro campo tipo imóvel
![Filtro campo tipo imóvel](./_assets/04-filtro-campo-tipo-imovel.png)

### Lista
![Lista](./_assets/05-lista.png)

### Cadastro - Inclusão
#### - Inclusão sem nada
![Inclusão sem nada](./_assets/06-inclusao-sem-nada.png)

#### - Inclusão preenchido corretamente
![Inclusão preenchido corretamente](./_assets/09-inclusao-preenchido-corretamente.png)

#### - Inclusão campos obrigatórios
![Inclusão campos obrigatórios](./_assets/07-inclusao-campos-obrigatorios.png)

#### - Inclusão preenchido incorretamente
![Inclusão preenchido incorretamente](./_assets/10-inclusao-preenchido-incorretamente.png)


### Cadastro - Consulta e Alteração
#### - Consulta
![Consulta](./_assets/11-consulta.png)

#### - Alteração
![Alteração](./_assets/12-alteracao.png)

## Entrega

A entrega será feita via upload da pasta completa `PXC` compactada (em `.zip` ou `.rar` de preferência) dentro da pasta de avaliação disponibilizada no espaço da aula. A solução inteira deve ser entregue (inclusive com o backend).

Utilize como nome do arquivo o padrão `Avaliação-MM4-MM5-[matrícula]` ex.: `Avaliação-MM5-T07007`.

Lembrando que uma aplicação usual deve seguir um padrão estrutural semelhante a este:

```makefile
PXC\
|
├── pxcbtoxn\                         # Pasta do projeto - TOs
├── pxcqctxn_Contrato\                # Pasta do projeto - Camada Q
├── pxcsctxn_Contrato\                # Pasta do projeto - Camada S
├── pxcuctxn_TestesAutomatizados\     # Pasta do projeto - Camada U
├── pxcw00xn_ProcessaTela\            # Pasta do projeto - Processamento de telas (incluído uma única vez)
├── pxcwctxn_Contrato\                # Pasta do projeto - Camada W
└── pxckcfxn.sln                      # Arquivo .NET da solução
```

Boa sorte e bom trabalho!

<!-- markdownlint-disable MD033 -->
<!-- markdownlint-disable MD037 -->
<!-- markdownlint-disable MD055 -->
<!-- markdownlint-disable MD056 -->

# Critérios de análise da avaliação: Gestão de Contratos Imobiliários

## Regras de pontuação MM4

| Categoria | Pontuação |
| :- | :-: |
| Estruturação e Organização de Solução e Projetos | 0.5 |
| TOs | 1.5 |
| Camada Q | 2.0 |
| Camada S | 3.0 |
| Camada U | 3.0 |
| **Total** | **10.0** |

## Regras de pontuação MM5

| Categoria | Pontuação |
| :- | :-: |
| Estruturação e Organização de Solução e Projetos | 0.5 |
| Projeto Processamento de Telas | 0.5 |
| Camada W - Estrutura e Navegação | 3.0 |
| Camada W - Funcionalidades | 4.2 |
| Camada W - Validações Impeditivas | 1.8 |
| **Total** | **10.0** |

### **Pontuação mínima para aprovação 14.0**

## Metodologia de pontuação

- A pontuação é distribuída proporcionalmente entre os itens avaliados: Conta-se o número de ocorrências do item avaliado e distribui-se a pontuação possível em **frações de igual valor** para cada repetição da ocorrência — se a ocorrência estiver correta, a pontuação é somada, caso contrário, é desconsiderada;
- Em casos excepcionais, quando o fracionamento igualitário de pontuação do item não for possível, as primeiras ocorrências recebem maior fração da pontuação — ou seja — as primeiras ocorrências encontradas podem ter um peso levemente superior às demais.

## Artefatos de referência

- **_Avaliação modelo_**: é uma reprodução de resolução da avaliação feita pelo próprio time de aprendizagem, que simula um "projeto ideal", servindo como referência para a correção das avaliações dos alunos;
- **_Gabarito de correções_**: é uma camada U com uma suíte de testes mais robusta, criada para automatização de correções de algumas partes das avaliações dos alunos.

## Detalhamento

### Estruturação e Organização de Solução e Projetos

| Item Avaliado | Pontuação Possível<br/>0.5 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| Estrutura Geral | 0.2 | **Estrutura de pastas** conforme padrão estabelecido. | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Solution | 0.2 | **Arquivo de solution** (`.sln`) agregando projetos **MM4** e **MM5**. | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Identificador curto | 0.1 | **Identificador curto de TO `ct`** aplicado corretamente nos projetos de camada Q, S, U e W. | Comparação com a _avaliação modelo_. |

### TOs

| Item Avaliado | Pontuação Possível<br/>1.5 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| Enum | 0.4 | **enum** devidamente estruturado para uso na tipagem e população (através do método `PopularRetorno(...)`) da respectiva propriedade, suportando uma tradução mais expressiva das enumerações `CHAR(1)` da modelagem.<br/> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Tipagem | 0.4 | **13 propriedades** (representação dos campos) tipados corretamente conforme a modelagem. Deve considerar o enum. Ordem é irrelevante | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Mapeamento de retorno | 0.4 | **13 propriedades** (representação dos campos) sendo populadas corretamente através do método `PopularRetorno(...)`. Deve considerar o enum. Ordem é irrelevante | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Wrappers | 0.3 | **13 propriedades** (representação dos campos) envelopadas nos wrappers corretos `CampoObrigatorio<T>` e `CampoOpcional<T>` conforme a modelagem. Deve considerar o enum. Ordem é irrelevante | Comparação com a _avaliação modelo_. |

### Projeto Processamento de Telas

| Item Avaliado | Pontuação Possível<br/>0.5 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| Projeto | 0.5 | Existência do projeto **Pxcw00xn** no arquivo de solution (`.sln`) e funcionamento adequado em _runtime_. | Comparação com a _avaliação modelo_. |

### Camada Q

| Item Avaliado | Pontuação Possível<br/>2.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Interações com a base de dados | 0.65 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (valores a serem inseridos) e saídas (retorno do comando), além de SAC implementado corretamente.<br/>- **0.3 para entradas**<br/>- **0.1 para saídas**<br/>- **0.25 para SAC** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contratos imobiliários: Interações com a base de dados | 0.35 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (critérios de filtragem) e saídas (valores a serem consultados), além do uso correto de alias.<br/>- **0.1 para entradas**<br/>- **0.15 para saídas**<br/>- **0.1 para alias** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Interações com a base de dados | 0.35 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (critérios de filtragem) e saídas (valores a serem consultados), além do uso correto de alias.<br/>- **0.1 para entradas**<br/>- **0.15 para saídas**<br/>- **0.1 para alias** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de CNPJ do fiador de um contrato imobiliário: Interações com a base de dados | 0.65 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (valores a serem atualizados e critérios de filtragem) e saídas (retorno do comando), além de SAC implementado corretamente.<br/>- **0.3 para entradas**<br/>- **0.1 para saídas**<br/>- **0.25 para SAC** | Comparação com a _avaliação modelo_. |

### Camada S

| Item Avaliado | Pontuação Possível<br/>3.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Funcionalidade | 0.4 | Inclusão bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC23_**, **_TC29_**, **_TC31_**, **_TC110_**, **_TC44_**, **_TC73_**, **_TC75_**, **_TC77_**, **_TC79_**, **_TC81_** e **_TC83_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US2 - Listagem de contratos imobiliários: Funcionalidade | 0.2 | Consulta bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC01_**, **_TC102_**, **_TC85_**, **_TC87_**, **_TC89_**, **_TC91_**, **_TC98_** e **_TC100_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Funcionalidade | 0.2 | Consulta bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC45_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US4 - Alteração do CNPJ do fiador do contrato imobiliário: Funcionalidade | 0.4 | Alteração bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TCXX_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Validações | 0.3 | **10 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.03 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TC37_**, **_TC39_**, **_TC46_**, **_TC57_**, **_TC59_**, **_TC63_** e **_TC69_**<br/>→ R02: **_TC25_**, **_TC27_**, **_TC33_** e **_TC35_**<br/>→ R03: **_TC104_**<br/>→ R04: **_TC41_**<br/>→ R05: **_TC48_**, **_TC50_**, **_TC106_**, **_TC53_** e **_TC55_**<br/>→ R06: **_TC57_**<br/>→ R07: **_TC61_**<br/>→ R08: **_TC65_** e **_TC67_**<br/>→ R09: **_TC71_**<br/>→ R10: **_TC107_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US2 - Listagem de contratos imobiliários: Validações | 0.15 | **3 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.05 por regra** com os respectivos testes com execução bem sucedida<br/>→ R02: **_TC93_**<br/>→ R03: **_TC94_** e **_TC96_** <br/>→ R04: **_TC01_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Validações | 0.15 | **3 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.05 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TCXX_**<br/>→ R02: **_TC47_**, **_TC49_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**<br/>→ R03: **_TCXX_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US4 - Alteração de CNPJ do fiador do contrato imobiliário: Validações | 0.3 | **5 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.06 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TCXX_**<br/>→ R02: **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**<br/>→ R03: **_TC101_**<br/>→ R04: **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TC99_**<br/>→ R05: Checagem manual (comparação com a _avaliação modelo_) | Aplicação do _gabarito de correções_ e comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Mapa de mensagens | 0.3 | Objeto de mapeamento de mensagens devidamente estruturado para uso nos retornos da camada S.<br/>- Herança da classe `Bergs.Pwx.Pwxoiexn.Mensagens.Mensagem` (pode ter qualquer nome)<br/>- 1 enum devidamente estruturado para os tipos de mensagem (pode ter qualquer nome)<br/>- **tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Mensagens | 0.2 | **14 critérios de aceitação** destacados da user story — validados pela suíte de testes do _gabarito de correções_.<br/>- **0.014 por critério**\* com os respectivos testes com execução bem sucedida<br/>→ CA02: **_TC38_**<br/>→ CA03: **_TC36_**, **_TC34_**, **_TC28_** e **_TC26_**<br/>→ CA04: **_TC40_**<br/>→ CA05: **_TC109_** e **_TC42_**<br/>→ CA06: **_TC47_**<br/>→ CA07: **_TC49_**, **_TC51_**, **_TC52_**, **_TC54_** e **_TC56_**<br/>→ CA08: **_TC58_**<br/>→ CA09: **_TC60_**<br/>→ CA10: **_TC62_**<br/>→ CA11: **_TC64_**<br/>→ CA12: **_TC66_** e **_TC68_**<br/>→ CA13: **_TC70_**<br/>→ CA14: **_TC72_**<br/>→ CA15: **_TC112_**<br/><br/><sub>* **0.015 nos primeiros 4 critérios** devido à impossibilidade de divisão igualitária.</sub> | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US2 - Listagem de contrato imobiliário: Mensagens | 0.1 | **3 critério de aceitação** destacado da user story — validado pela suíte de testes do _gabarito de correções_.<br/>- **0.03 por critério**\* com os respectivos testes com execução bem sucedida<br/>→ CA03: **_TC08_**<br/>→ CA04: **_TC95_**, **_TC97_**<br/>→ CA05: **_TC07_**<br/><br/><sub>* **0.04 no primeiro critério** devido à impossibilidade de divisão igualitária.</sub> | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Mensagens | 0.1 | **3 critérios de aceitação** destacados da user story — validados pela suíte de testes do _gabarito de correções_.<br/>- **0.03 por critério** com os respectivos testes com execução bem sucedida<br/>→ CA02: **_TCXX_**<br/>→ CA03: **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**<br/>→ CA04: **_TCXX_**<br/><br/><sub>* **0.04 no primeiro critério** devido à impossibilidade de divisão igualitária.</sub> | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US4 - Alteração de CNPJ do fiador de contrato imobiliário: Mensagens | 0.2 | **5 critérios de aceitação** destacados da user story — validados pela suíte de testes do _gabarito de correções_.<br/>- **0.04 por critério**\* com os respectivos testes com execução bem sucedida<br/>→ CA02: **_TC90_**<br/>→ CA03: **_TC78_**, **_TC80_**, **_TC82_**, **_TC84_**, **_TC86_**, **_TC88_**<br/>→ CA04: **_TCXX_**<br/>→ CA05: **_TC90_**, **_TC92_**, **_TCXX_**, **_TCXX_**, **_TCXX_**, **_TCXX_**<br/>→ CA06: **_TCXX_** | Aplicação do _gabarito de correções_. |

### Camada U

| Item Avaliado | Pontuação Possível<br/>3.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Testes de funcionalidade bem sucedida | 0.7 | **Teste de integração** com execução bem sucedida e contendo as asserções de inclusão bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contrato imobiliário: Testes de funcionalidade bem sucedida | 0.25 | **Teste de integração** com execução bem sucedida e contendo as asserções de consulta bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Testes de funcionalidade bem sucedida | 0.25 | **Teste de integração** com execução bem sucedida e contendo as asserções de consulta bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de CNPJ de fiador do contrato imobiliário: Testes de funcionalidade bem sucedida | 0.7 | **Teste de integração** com execução bem sucedida e contendo as asserções de alteração bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Testes de falha | 0.3 | **Testes de integração para 14 critérios de aceitação** destacados da user story (ao menos 1 para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagens de retorno idênticas às dos critérios**.<br/>- **0.0212 por critério**\*<br/>→ CA02<br/>→ CA03<br/>→ CA04<br/>→ CA05<br/>→ CA06<br/>→ CA07<br/>→ CA08<br/>→ CA09<br/>→ CA10<br/>→ CA11<br/>→ CA12<br/>→ CA13<br/>→ CA14<br/>→ CA15<br/><br/><sub>* **0.022 nos primeiros 4 critérios** devido à impossibilidade de divisão igualitária.</sub> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contratos imobiliários: Testes de falha | 0.15 | **Testes de integração para 3 critério de aceitação** destacado da user story (ao menos 1 teste para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagem de retorno idêntica à do critério**.<br/>- **0.05 por critério**\*<br/>→ CA03<br/>→ CA04<br/>→ CA05<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Testes de falha | 0.15 | **Testes de integração para 3 critérios de aceitação** destacados da user story (ao menos 1 para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagens de retorno idênticas às dos critérios**.<br/>- **0.05 por critério**<br/>→ CA02<br/>→ CA03<br/>→ CA04 | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de CNPJ do fiador do contrato imobiliário: Testes de falha | 0.25 | **Testes de integração para 5 critérios de aceitação** destacados da user story (ao menos 1 para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagens de retorno idênticas às dos critérios**.<br/>- **0.05 por critério**\*<br/>→ CA02<br/>→ CA03<br/>→ CA04<br/>→ CA05<br/>→ CA06 | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Mock | 0.25 | Objeto mock devidamente estruturado para uso nos testes da camada U e ao menos 1 **teste unitário** de falha ou exceção fazendo uso de um dos métodos de setup do objeto mock — com execução bem sucedida e contendo asserções de falha ou exceção.<br/>- Herança da classe `Bergs.Bth.Bthsmoxn.AbstractMmMock` (pode ter qualquer nome)<br/>- 1 método de setup "mockando" a camada Q e os seus métodos conforme necessidade (pode ter qualquer nome)<br/>- **tudo ou nada** | Comparação com a _avaliação modelo_. |

### Camada W - Estrutura e Navegação

| Item Avaliado | Pontuação Possível<br/>3.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inputs tela **Cadastro - Inclusão** | 0.7 | **8 inputs** tipados e mascarados corretamente, conforme definido nas R01.<br/>- **0.0875 por input**<br/>- Labels idealmente parecidas com as da avaliação modelo — outros textos a serem avaliados caso a caso<br/>- Ordem é irrelevante<br/><br/> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Inputs tela **Filtro** | 0.7 | **3 inputs** tipados e mascarados corretamente, conforme definido na R01 da US.<br/>- **0.24 no primeiro input e 0.23 nos demais**<br/>- Labels iguais as da avaliação modelo<br/>- Ordem é irrelevante | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Colunas tela **Lista** | 0.8 | **9 colunas** mascaradas corretamente, conforme definido na R04 da US.<br/>- **0.4 se tiver todas as colunas pedidas e 0.4 se não tiver nenhuma coluna a mais**<br/>- Títulos iguais com as da avaliação modelo<br/>- Ordem é irrelevante | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Inputs tela **Cadastro - Alteração** | 0.2 | **1 input** tipado e mascarado corretamente, conforme definido na R03.<br/>- Labels idênticas as da avaliação modelo<br/>- **Tudo ou nada**<br/> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Fluxos de navegação | 0.6 | **4 fluxos** principais de transição entre telas e modos funcionando corretamente.<br/>- **0.15 por fluxo**<br/>→ Tela **Filtro** para tela **Cadastro** em modo _Inclusão_<br/>→ Tela **Filtro** para tela **Lista**<br/>→ Tela **Lista** (clique em um registro da lista) para tela **Cadastro** em modo _Consulta_<br/>→ Tela **Cadastro** em modo _Consulta_ para tela **Cadastro** em modo _Alteração_ | Comparação com a _avaliação modelo_. |

### Camada W - Funcionalidades

| Item Avaliado | Pontuação Possível<br/>4.2 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Funcionalidade | 1 | Inclusão bem sucedida — validada por teste funcional manual com base no CA01.<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contratos imobiliários: Funcionalidade | 1 | Consulta bem sucedida — validada por teste funcional manual com base nos CA01 e CA02.<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de contrato imobiliário: Funcionalidade | 1 | Consulta bem sucedida — validada por teste funcional manual com base no CA01.<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de CNPJ do fiador de contrato imobiliário: Funcionalidade | 1 | Alteração bem sucedida — validada por teste funcional manual com base no CA01.<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Retirada de funcionalidade: Exclusão/Remoção | 0.1 | Retirada da funcionalidade de exclusão/remoção.<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Retirada de funcionalidade: Impressão | 0.1 | Retirada da funcionalidade de impressão.<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |


### Camada W - Validações Impeditivas

| Item Avaliado | Pontuação Possível<br/>1.8 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de novo contrato imobiliário: Validações | 0.8 | **13 critérios de aceitação** destacados da US (com base em 13 regras) — validados por teste funcional manual: CA02, CA03, CA04, CA05, CA06, CA07, CA08, CA09, CA10, CA11, CA12, CA13 e CA14.<br/>- **0.062 por critério no primeiro critério, 0.0615 nos demais** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contratos imobiliários: Validações | 0.2 | **2 critérios de aceitação** destacados da US (com base em 2 regras) — validados por teste funcional manual: CA03 e CA04.<br/>- **0.1 por critério** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Inputs tela **Cadastro - Consulta** | 0.2 | Todos os inputs desabilitados enquanto a tela **Cadastro** estiver em modo _Consulta_.<br/>- **Tudo ou nada**<br/><br/><sub>* `Tipo imóvel` nunca estará desabilitado, pois existe um bug conhecido em relação ao `mm-combo` — esse problema deve ser desconsiderado (não impactar a pontuação).</sub> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de situação de contrato imobiliário: Validações | 0.6 | **4 critérios de aceitação** destacados da US (com base em 4 regras) — validados por teste funcional manual: CA02, CA03, CA04 e CA05.<br/>- **0.15 por critério** | Comparação com a _avaliação modelo_. |

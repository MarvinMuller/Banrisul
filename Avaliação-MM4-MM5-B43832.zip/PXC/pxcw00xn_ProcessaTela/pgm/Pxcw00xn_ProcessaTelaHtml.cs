﻿using System.Web.Services;
using Bergs.Pwx.Pwxoiexn.IN;

namespace Bergs.Pxc.Pxcw00xn
{
    /// <summary>Classe responsável pelo processamento das telas da aplicação.</summary>
    [WebService(Namespace = "Bergs.Pxc.Pxcw00xn")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ProcessaTelaHtml : AplicacaoProcessaTelaHtml
    {
        #region Métodos
        #endregion
    }
}
 
﻿'use strict';

function Pxcs00hn() { }

Pxcs00hn.prototype = {
    load: function () {
        oInfra.getTela().mostrarTela('TelaInicial');
    }
};

﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcbtoxn")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcbtoxn")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2026")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("dea81c36-390c-4a98-a28b-1dea9d47f426")]
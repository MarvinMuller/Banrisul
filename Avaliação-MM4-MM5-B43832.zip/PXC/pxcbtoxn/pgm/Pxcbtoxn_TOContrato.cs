﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Validacoes;
using Bergs.Pwx.Pwxoiexn.Btr;
using Bergs.Pxc.Pxcbtoxn.pgm;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CONTRATO da base de dados PXC.</summary>
    public class TOContrato : TOTabela
  {

        #region Propriedades
        /// <summary></summary>
        public const string CNPJ_INVALIDO = "Um CNPJ válido deve ser informado.";

        #region Chaves Primárias
        /// <summary>Campo NUMERO_CONTRATO da tabela CONTRATO.</summary>
        [XmlAttribute("numero_contrato")]
        [CampoTabela("NUMERO_CONTRATO", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal, Tamanho = 7, Precisao = 7)]
        public CampoObrigatorio<decimal> NumeroContrato { get; set; }
        #endregion
        
        #region Campos Obrigatórios
        /// <summary>Campo AGENCIA da tabela CONTRATO.</summary>
        [XmlAttribute("agencia")]
        [CampoTabela("AGENCIA", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<string> Agencia { get; set; }
        
        /// <summary>Campo CNPJ da tabela CONTRATO.</summary>
        [XmlAttribute("cnpj")]
        [CampoTabela("CNPJ", Obrigatorio = true, TipoParametro = DbType.Decimal, Tamanho = 14, Precisao = 14)]
        [CNPJ(mensagemErro: CNPJ_INVALIDO)]
        public CampoObrigatorio<decimal> Cnpj { get; set; }
        
        /// <summary>Campo DATA_ASSINATURA da tabela CONTRATO.</summary>
        [XmlAttribute("data_assinatura")]
        [CampoTabela("DATA_ASSINATURA", Obrigatorio = true, TipoParametro = DbType.DateTime, Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataAssinatura { get; set; }
        
        /// <summary>Campo DATA_NASCIMENTO da tabela CONTRATO.</summary>
        [XmlAttribute("data_nascimento")]
        [CampoTabela("DATA_NASCIMENTO", Obrigatorio = true, TipoParametro = DbType.DateTime, Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DataNascimento { get; set; }
        
        /// <summary>Campo NOME_CLIENTE da tabela CONTRATO.</summary>
        [XmlAttribute("nome_cliente")]
        [CampoTabela("NOME_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 35, Precisao = 35)]
        public CampoObrigatorio<string> NomeCliente { get; set; }
        
        /// <summary>Campo ULT_ATUALIZACAO da tabela CONTRATO.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao { get; set; }
        #endregion
        
        #region Campos Opcionais
        /// <summary>Campo CEP da tabela CONTRATO.</summary>
        [XmlAttribute("cep")]
        [CampoTabela("CEP", TipoParametro = DbType.String, Tamanho = 8, Precisao = 8)]
        public CampoOpcional<string> Cep { get; set; }
        
        /// <summary>Campo CIDADE da tabela CONTRATO.</summary>
        [XmlAttribute("cidade")]
        [CampoTabela("CIDADE", TipoParametro = DbType.String, Tamanho = 30, Precisao = 30)]
        public CampoOpcional<string> Cidade { get; set; }
        
        /// <summary>Campo ENDERECO da tabela CONTRATO.</summary>
        [XmlAttribute("endereco")]
        [CampoTabela("ENDERECO", TipoParametro = DbType.String, Tamanho = 40, Precisao = 40)]
        public CampoOpcional<string> Endereco { get; set; }
        
        /// <summary>Campo TIPO_IMOVEL da tabela CONTRATO.</summary>
        [XmlAttribute("tipo_imovel")]
        [CampoTabela("TIPO_IMOVEL", TipoParametro = DbType.String, Tamanho = 1, Precisao = 1)]
        public CampoOpcional<string> TipoImovel { get; set; }
        
        /// <summary>Campo UF da tabela CONTRATO.</summary>
        [XmlAttribute("uf")]
        [CampoTabela("UF", TipoParametro = DbType.String, Tamanho = 2, Precisao = 2)]
        public CampoOpcional<string> Uf { get; set; }
        
        /// <summary>Campo VALOR_IMOVEL da tabela CONTRATO.</summary>
        [XmlAttribute("valor_imovel")]
        [CampoTabela("VALOR_IMOVEL", TipoParametro = DbType.Decimal, Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<decimal> ValorImovel { get; set; }
        #endregion
        
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "NUMERO_CONTRATO":
                        NumeroContrato = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "AGENCIA":
                        Agencia = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "CNPJ":
                        Cnpj = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "DATA_ASSINATURA":
                        DataAssinatura = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "DATA_NASCIMENTO":
                        DataNascimento = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "NOME_CLIENTE":
                        NomeCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        UltAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "CEP":
                        Cep = LerCampoOpcional<String>(campo);
                        break;
                    case "CIDADE":
                        Cidade = LerCampoOpcional<String>(campo);
                        break;
                    case "ENDERECO":
                        Endereco = LerCampoOpcional<String>(campo);
                        break;
                    case "TIPO_IMOVEL":
                        TipoImovel = LerCampoOpcional<String>(campo);
                        break;
                    case "UF":
                        Uf = LerCampoOpcional<String>(campo);
                        break;
                    case "VALOR_IMOVEL":
                        ValorImovel = LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}
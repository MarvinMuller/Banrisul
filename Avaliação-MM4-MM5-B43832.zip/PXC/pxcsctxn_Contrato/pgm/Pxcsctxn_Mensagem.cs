﻿using System;

namespace Bergs.Pxc.Pxcsctxn
{
    /// <summary>Mensagens previstas para o componente</summary>
    public enum TipoMensagem
    {
        /// <summary>Falha da regra de negócio</summary>
        Falha,
        ///
        /// ALTERAR
        ///
        FalhaAlterarCNPJ,
        ///
        FalhaAlterarNumeroContrato,
        ///
        FalhaAlterarRegistroInexistente,
        ///
        /// EXCLUIR
        ///
        FalhaExcluirNumeroContrato,
        ///
        /// INCLUIR
        ///
        FalhaIncluirAgencia,
        ///
        FalhaIncluirCNPJ,
        ///
        FalhaIncluirDataAssinatura,
        ///
        FalhaIncluirDataNascimento,
        ///
        FalhaIncluirNomeCliente,
        ///
        FalhaIncluirNumeroContrato,
        ///
        FalhaIncluirTipoImovel,
        ///
        FalhaIncluirValorImovel,
        ///
        FalhaIncluirRegistroDuplicado,
        /// 
        /// LISTAR
        /// 
        FalhaListarNomeCliente,
        ///
        FalhaListarRegistroInexistente,
        ///
        FalhaListarTipoImovel,
        ///
        /// OBTER
        ///
        FalhaObterNumeroContrato,
        ///
        FalhaObterRegistroInexistente
    }

    ///
    public class Mensagem : Bergs.Pwx.Pwxoiexn.Mensagens.Mensagem
    {
        /// <summary>
        /// Mensagem
        /// </summary>
        private string mensagem;
        
        /// <summary>
        /// Tipo de mensagem
        /// </summary>
        private Pxcsctxn.TipoMensagem tipoMensagem;
        
        /// <summary>
        /// Mensagem para o usuário
        /// </summary>
        public override string ParaUsuario
        {
            get { return this.ParaOperador; }
        }

        /// <summary>
        /// Mensagem para o operador
        /// </summary>
        public override string ParaOperador
        {
            get { return this.mensagem; }
        }

        /// <summary>
        /// Identificador
        /// </summary>
        public override string Identificador
        {
            get { return tipoMensagem.ToString(); }
        }

        /// <summary>
        /// Construtor da classe Mensagem
        /// </summary>
        /// <param name="mensagem">Mensagem</param>
        /// <param name="argumentos">Argumentos</param>
        public Mensagem(Pxcsctxn.TipoMensagem mensagem, params string[] argumentos)
        {
            tipoMensagem = mensagem;

            switch (mensagem)
            {
                case Pxcsctxn.TipoMensagem.Falha:
                    this.mensagem = string.Empty;
                    break;
                //
                // ALTERAR
                //
                case TipoMensagem.FalhaAlterarCNPJ:
                    this.mensagem = "Um CNPJ válido deve ser informado.";
                    break;
                case TipoMensagem.FalhaAlterarNumeroContrato:
                    this.mensagem = "Um número válido de contrato deve ser informado (entre 1000000 e 9999999).";
                    break;
                case TipoMensagem.FalhaAlterarRegistroInexistente:
                    this.mensagem = "Não existe um contrato cadastrado para o critério informado.";
                    break;
                //
                // EXCLUIR
                //
                case TipoMensagem.FalhaExcluirNumeroContrato:
                    this.mensagem = "EXCLUIR NUMERO CONTRATO";
                    break;
                //
                // INCLUIR 
                //
                case TipoMensagem.FalhaIncluirAgencia:
                    this.mensagem = "Um número válido de agência deve ser informado (entre 1000 e 9999).";
                    break;
                case TipoMensagem.FalhaIncluirCNPJ:
                    this.mensagem = "Um CNPJ válido deve ser informado.";
                    break;
                case TipoMensagem.FalhaIncluirDataAssinatura:
                    this.mensagem = "Uma data de assinatura deve ser informada.";
                    break;
                case TipoMensagem.FalhaIncluirDataNascimento:
                    this.mensagem = "Uma data de nascimento deve ser informada.";
                    break;
                case TipoMensagem.FalhaIncluirNomeCliente:
                    this.mensagem = "Um nome válido de cliente deve ser informado (máximo de 35 caracteres).";
                    break;
                case TipoMensagem.FalhaIncluirNumeroContrato:
                    this.mensagem = "Um número válido de contrato deve ser informado (entre 1000000 e 9999999).";
                    break;
                case TipoMensagem.FalhaIncluirTipoImovel:
                    this.mensagem = "Um tipo de imóvel válido deve ser informado 'C', 'A', 'T' ou 'P'.";
                    break;
                case TipoMensagem.FalhaIncluirValorImovel:
                    this.mensagem = "Um valor válido de imóvel deve ser informado (maior que zero).";
                    break;
                case TipoMensagem.FalhaIncluirRegistroDuplicado:
                    this.mensagem = "Já existe na base de dados um contrato com o número de contrato informados.";
                    break;
                //
                // LISTAR
                //
                case TipoMensagem.FalhaListarNomeCliente:
                    this.mensagem = "Um nome válido de cliente deve ser informado (máximo de 35 caracteres).";
                    break;
                case TipoMensagem.FalhaListarRegistroInexistente:
                    this.mensagem = "Nenhum registro encontrado.";
                    break;
                case TipoMensagem.FalhaListarTipoImovel:
                    this.mensagem = "Um tipo de imóvel válido deve ser informado 'C', 'A', 'T' ou 'P'.";
                    break;
                //
                // OBTER
                //
                case TipoMensagem.FalhaObterNumeroContrato:
                    this.mensagem = "Um número válido de contrato deve ser informado (entre 1000000 e 9999999).";
                    break;
                case TipoMensagem.FalhaObterRegistroInexistente:
                    this.mensagem = "Não existe um contrato cadastrado para o critério informado.";
                    break;
                default:
                    this.mensagem = "Mensagem não definida.";
                    break;
            }
        }
    }
}

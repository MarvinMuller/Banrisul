﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqctxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Relatorios;
using Bergs.Pwx.Pwxoiexn.RN;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bergs.Pxc.Pxcsctxn
{ 
    /// <summary>Classe que possui as regras de negócio para o acesso da tabela CONTRATO da base de dados PXC.</summary>
    public class Contrato : AplicacaoRegraNegocio
    {
        #region Métodos
        private bool AgenciaValida(string agencia)
        {
            int.TryParse(agencia, out int agenciaInt);

            return agenciaInt >= 1000 && agenciaInt <= 9999;
        }

        private bool NumeroContratoValido(decimal contrato)
        {
            if (contrato >= 1000000 && contrato <= 9999999)
                return contrato == Math.Truncate(contrato);

            return false;
        }

        private bool NomeClienteValido(string nomeCliente)
        {
            return !string.IsNullOrWhiteSpace(nomeCliente) && nomeCliente.Length <= 35;
        }

        private bool TipoImovelValido(string tipoImovel)
        {
            return tipoImovel == "C" || tipoImovel == "A" || tipoImovel == "T" || tipoImovel == "P";
        }

        private bool ValorImovelValido(decimal valorImovel)
        {
            return valorImovel > 0;
        }
        /// <summary>Altera registro da tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Alterar(TOContrato toContrato)
        {
            try
            {
                Pxcqctxn.Contrato bdContrato;
                Retorno<int> alteracaoContrato;                
                
                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toContrato.NumeroContrato.FoiSetado || !NumeroContratoValido(toContrato.NumeroContrato))
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaAlterarNumeroContrato));
                }
                if (!toContrato.Cnpj.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaAlterarCNPJ));
                }
                if (!ValidarTO(toContrato, out var listaRetornoValidacao))
                    return Infra.RetornarFalha<int>(new ObjetoInvalidoMensagem(listaRetornoValidacao));
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdContrato = this.Infra.InstanciarBD<Pxcqctxn.Contrato>();
                var toObter = new TOContrato()
                {
                    NumeroContrato = toContrato.NumeroContrato
                };
                var retornoObter = Obter(toObter);

                if (!retornoObter.OK)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaAlterarRegistroInexistente));
                }
                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    alteracaoContrato = bdContrato.Alterar(toContrato);
                    if (!alteracaoContrato.OK)
                    {
                        return alteracaoContrato;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(alteracaoContrato.Dados, new OperacaoRealizadaMensagem("Alteração"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
    
        /// <summary>Conta quantidade de registros da tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<long> Contar(TOContrato toContrato)
        {
            try
            {
                Pxcqctxn.Contrato bdContrato;
                Retorno<long> contagemContrato;
                
                #region Validação de regras de negócio
                #endregion
            
                bdContrato = this.Infra.InstanciarBD<Pxcqctxn.Contrato>();

                contagemContrato = bdContrato.Contar(toContrato);
                if (!contagemContrato.OK)
                {
                    return contagemContrato;
                }
                
                return this.Infra.RetornarSucesso(contagemContrato.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<long>(ex);
            }
        }
    
        /// <summary>Exclui registro da tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Excluir(TOContrato toContrato)
        {
            try
            {
                Pxcqctxn.Contrato bdContrato;
                Retorno<int> exclusaoContrato;
                
                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toContrato.NumeroContrato.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaExcluirNumeroContrato));
                }
                #endregion
      
                #region Validação de regras de negócio
                #endregion

                bdContrato = this.Infra.InstanciarBD<Pxcqctxn.Contrato>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    exclusaoContrato = bdContrato.Excluir(toContrato);
                    if (!exclusaoContrato.OK)
                    {
                        return exclusaoContrato;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(exclusaoContrato.Dados, new OperacaoRealizadaMensagem("Exclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
    
        /// <summary>Gera relatório da tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta e o nome do relatório gerado, ou as informações de erro.</returns>
        public virtual Retorno<string> Imprimir(TOContrato toContrato)
        {
            try
            {
                Retorno<List<TOContrato>> listagemContrato;
                StringBuilder linha;
                
                //Lista registros da tabela
                listagemContrato = this.Listar(toContrato, null);
                if (!listagemContrato.OK)
                {
                    return this.Infra.RetornarFalha<List<TOContrato>, String>(listagemContrato);
                }
                
                //Monta relatório com os dados da listagem
                using (RelatorioPadrao relatorio = new RelatorioPadrao(this.Infra))
                {   
                    //Define colunas do relatório
                    relatorio.Colunas.Add(new Coluna("AGENCIA", 4));
                    relatorio.Colunas.Add(new Coluna("CEP", 8));
                    relatorio.Colunas.Add(new Coluna("CIDADE", 30));
                    relatorio.Colunas.Add(new Coluna("CNPJ", 14));
                    relatorio.Colunas.Add(new Coluna("DATA_ASSINATURA", 26));
                    relatorio.Colunas.Add(new Coluna("DATA_NASCIMENTO", 26));
                    relatorio.Colunas.Add(new Coluna("ENDERECO", 40));
                    relatorio.Colunas.Add(new Coluna("NOME_CLIENTE", 35));
                    relatorio.Colunas.Add(new Coluna("NUMERO_CONTRATO", 7));
                    relatorio.Colunas.Add(new Coluna("TIPO_IMOVEL", 1));
                    relatorio.Colunas.Add(new Coluna("UF", 2));
                    relatorio.Colunas.Add(new Coluna("ULT_ATUALIZACAO", 26));
                    relatorio.Colunas.Add(new Coluna("VALOR_IMOVEL", 17));

                    linha = new StringBuilder();
                    //Monta linhas do relatório
                    foreach(TOContrato toSaida in listagemContrato.Dados)
                    {
                        linha.Append(toSaida.Agencia.ToString().PadRight(relatorio.Colunas["AGENCIA"].Tamanho));
                        linha.Append(toSaida.Cep.ToString().PadRight(relatorio.Colunas["CEP"].Tamanho));
                        linha.Append(toSaida.Cidade.ToString().PadRight(relatorio.Colunas["CIDADE"].Tamanho));
                        linha.Append(toSaida.Cnpj.ToString().PadRight(relatorio.Colunas["CNPJ"].Tamanho));
                        linha.Append(toSaida.DataAssinatura.ToString().PadRight(relatorio.Colunas["DATA_ASSINATURA"].Tamanho));
                        linha.Append(toSaida.DataNascimento.ToString().PadRight(relatorio.Colunas["DATA_NASCIMENTO"].Tamanho));
                        linha.Append(toSaida.Endereco.ToString().PadRight(relatorio.Colunas["ENDERECO"].Tamanho));
                        linha.Append(toSaida.NomeCliente.ToString().PadRight(relatorio.Colunas["NOME_CLIENTE"].Tamanho));
                        linha.Append(toSaida.NumeroContrato.ToString().PadRight(relatorio.Colunas["NUMERO_CONTRATO"].Tamanho));
                        linha.Append(toSaida.TipoImovel.ToString().PadRight(relatorio.Colunas["TIPO_IMOVEL"].Tamanho));
                        linha.Append(toSaida.Uf.ToString().PadRight(relatorio.Colunas["UF"].Tamanho));
                        linha.Append(toSaida.UltAtualizacao.ToString().PadRight(relatorio.Colunas["ULT_ATUALIZACAO"].Tamanho));
                        linha.Append(toSaida.ValorImovel.ToString().PadRight(relatorio.Colunas["VALOR_IMOVEL"].Tamanho));

                        relatorio.AdicionarLinha(linha.ToString());
                        linha.Length = 0;
                    }
                    
                    return this.Infra.RetornarSucesso(relatorio.NomeArquivoVirtual, new OperacaoRealizadaMensagem());
                }                
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<String>(ex);
            }
        }
    
        /// <summary>Inclui registro na tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Incluir(TOContrato toContrato)
        {
            try
            {
                Pxcqctxn.Contrato bdContrato;
                Retorno<int> inclusaoContrato;

                #region Validação de campos
                //Valida que os campos obrigatórios foram informados

                if (!toContrato.NumeroContrato.FoiSetado || !NumeroContratoValido(toContrato.NumeroContrato))
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirNumeroContrato));
                }
                if (!toContrato.DataAssinatura.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirDataAssinatura));
                }
                if (!toContrato.NomeCliente.FoiSetado || !NomeClienteValido(toContrato.NomeCliente))
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirNomeCliente));
                }
                if (!toContrato.Agencia.FoiSetado || !AgenciaValida(toContrato.Agencia))
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirAgencia));
                }
                if (!toContrato.DataNascimento.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirDataNascimento));
                }
                if (!toContrato.TipoImovel.FoiSetado || !TipoImovelValido(toContrato.TipoImovel))
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirTipoImovel));
                }
                if (!toContrato.ValorImovel.FoiSetado || !ValorImovelValido(toContrato.ValorImovel))
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirValorImovel));
                }
                if (!toContrato.Cnpj.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirCNPJ));
                }
                if (!ValidarTO(toContrato, out var listaRetornoValidacao))
                    return Infra.RetornarFalha<int>(new ObjetoInvalidoMensagem(listaRetornoValidacao));
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdContrato = this.Infra.InstanciarBD<Pxcqctxn.Contrato>();
                
                var toObter = new TOContrato()
                {
                    NumeroContrato = toContrato.NumeroContrato
                };
                var retornoObter = Obter(toObter);

                if (retornoObter.OK)
                {
                    return this.Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirRegistroDuplicado));
                }
                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    inclusaoContrato = bdContrato.Incluir(toContrato);
                    if (!inclusaoContrato.OK && (inclusaoContrato.Mensagem is RegistroDuplicadoMensagem))
                    {
                        return Infra.RetornarFalha<int>(new Mensagem(TipoMensagem.FalhaIncluirRegistroDuplicado));
                    }
                    if (!inclusaoContrato.OK)
                    {
                        return inclusaoContrato;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(inclusaoContrato.Dados, new OperacaoRealizadaMensagem("Inclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
    
        /// <summary>Lista registros da tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <param name="toPaginacao">Classe da infra-estrutura contendo as informações de paginação.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<List<TOContrato>> Listar(TOContrato toContrato, TOPaginacao toPaginacao)
        {
            try
            {
                Pxcqctxn.Contrato bdContrato;
                Retorno<List<TOContrato>> listagemContrato;

                #region Validação de regras de negócio
                if (toContrato.TipoImovel.FoiSetado && !TipoImovelValido(toContrato.TipoImovel))
                {
                    return this.Infra.RetornarFalha<List<TOContrato>>(new Mensagem(TipoMensagem.FalhaListarTipoImovel));
                }
                if (toContrato.NomeCliente.FoiSetado && !NomeClienteValido(toContrato.NomeCliente))
                {
                    return this.Infra.RetornarFalha<List<TOContrato>>(new Mensagem(TipoMensagem.FalhaListarNomeCliente));
                }
                #endregion

                bdContrato = this.Infra.InstanciarBD<Pxcqctxn.Contrato>();

                listagemContrato = bdContrato.Listar(toContrato, toPaginacao);

                if (!listagemContrato.OK)
                {
                    return listagemContrato;
                }
                if (listagemContrato.Dados.Count == 0)
                {
                    return this.Infra.RetornarFalha<List<TOContrato>>(new Mensagem(TipoMensagem.FalhaListarRegistroInexistente));
                }

                return this.Infra.RetornarSucesso(listagemContrato.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<List<TOContrato>>(ex);
            }
        }
    
        /// <summary>Obtém registro da tabela CONTRATO.</summary>
        /// <param name="toContrato">Transfer Object de entrada referente à tabela CONTRATO.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOContrato> Obter(TOContrato toContrato)
        {
            try
            {
                Pxcqctxn.Contrato bdContrato;
                Retorno<TOContrato> obtencaoContrato;
                
                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toContrato.NumeroContrato.FoiSetado || !NumeroContratoValido(toContrato.NumeroContrato))
                {
                    return this.Infra.RetornarFalha<TOContrato>(new Mensagem(TipoMensagem.FalhaObterNumeroContrato));
                }
                #endregion

                #region Validação de regras de negócio
                #endregion

                bdContrato = this.Infra.InstanciarBD<Pxcqctxn.Contrato>();

                obtencaoContrato = bdContrato.Obter(toContrato);
                if (!obtencaoContrato.OK)
                {
                    return this.Infra.RetornarFalha<TOContrato>(new Mensagem(TipoMensagem.FalhaObterRegistroInexistente));
                }
                
                return this.Infra.RetornarSucesso(obtencaoContrato.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOContrato>(ex);
            }
        }
        #endregion
	} 
}
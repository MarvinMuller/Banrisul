﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcuctxn.Test")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcuctxn.Test")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2026")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("4b79a367-084a-42f3-acfb-919f2797b509")]
﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqctxn;
using Bergs.Pxc.Pxcsctxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuctxn.Tests
{
	
	///  <summary>
	/// Contém os métodos de mock para testes da classe Contrato.
	/// </summary>
	public class MockContrato : AbstractMmMock
	{
		#region Construtor
		///  <summary>
		/// Construtor da classe de mocks
		/// </summary>
		/// <param name="infra">Infra</param>
		public MockContrato(InfraTeste infra) : 
				base(infra)
		{
		}
		#endregion
		#region Métodos de mock de Falha.
		///  <summary>
		/// Registra um mock para o método Alterar.
		/// </summary>
		public void AlterarComFalha()
		{
            Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
            mockContratoBD.Obter(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.RetornarFalha<TOContrato>(new Mensagem(TipoMensagem.FalhaAlterarRegistroInexistente)));
        }
		///  <summary>
		/// Registra um mock para o método Contar.
		/// </summary>
		public void ContarComFalha()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Contar(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.RetornarFalha<Int64>(new MensagemFalhaTestador("Contar")));
		}
		///  <summary>
		/// Registra um mock para o método Excluir.
		/// </summary>
		public void ExcluirComFalha()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Excluir(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.RetornarFalha<Int32>(new MensagemFalhaTestador("Excluir")));
		}
		///  <summary>
		/// Registra um mock para o método Incluir.
		/// </summary>
		public void IncluirComFalha()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Incluir(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.RetornarFalha<Int32>(new MensagemFalhaTestador("Incluir")));
		}
		///  <summary>
		/// Registra um mock para o método Listar.
		/// </summary>
		public void ListarComFalha()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Listar(MmMockArgumento.Qualquer<TOContrato>(), MmMockArgumento.Qualquer<TOPaginacao>()).Retorna(this.Infra.RetornarFalha<List<TOContrato>>(new MensagemFalhaTestador("Listar")));
		}
		///  <summary>
		/// Registra um mock para o método Obter.
		/// </summary>
		public void ObterComFalha()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Obter(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.RetornarFalha<TOContrato>(new MensagemFalhaTestador("Obter")));
		}
		#endregion
		#region Métodos de mock de Excecao.
		///  <summary>
		/// Registra um mock para o método Alterar.
		/// </summary>
		public void AlterarComExcecao()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Alterar(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.TratarExcecao<Int32>(new Exception("Simulação de teste de exceção do método Alterar.")));
		}
		///  <summary>
		/// Registra um mock para o método Contar.
		/// </summary>
		public void ContarComExcecao()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Contar(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.TratarExcecao<Int64>(new Exception("Simulação de teste de exceção do método Contar.")));
		}
		///  <summary>
		/// Registra um mock para o método Excluir.
		/// </summary>
		public void ExcluirComExcecao()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Excluir(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.TratarExcecao<Int32>(new Exception("Simulação de teste de exceção do método Excluir.")));
		}
		///  <summary>
		/// Registra um mock para o método Incluir.
		/// </summary>
		public void IncluirComExcecao()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Incluir(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.TratarExcecao<Int32>(new Exception("Simulação de teste de exceção do método Incluir.")));
		}
		///  <summary>
		/// Registra um mock para o método Listar.
		/// </summary>
		public void ListarComExcecao()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Listar(MmMockArgumento.Qualquer<TOContrato>(), MmMockArgumento.Qualquer<TOPaginacao>()).Retorna(this.Infra.TratarExcecao<List<TOContrato>>(new Exception("Simulação de teste de exceção do método Listar.")));
		}
		///  <summary>
		/// Registra um mock para o método Obter.
		/// </summary>
		public void ObterComExcecao()
		{
			Pxcqctxn.Contrato mockContratoBD = this.Mock.Para<Pxcqctxn.Contrato>();
			mockContratoBD.Obter(MmMockArgumento.Qualquer<TOContrato>()).Retorna(this.Infra.TratarExcecao<TOContrato>(new Exception("Simulação de teste de exceção do método Obter.")));
		}
		#endregion
	}
}


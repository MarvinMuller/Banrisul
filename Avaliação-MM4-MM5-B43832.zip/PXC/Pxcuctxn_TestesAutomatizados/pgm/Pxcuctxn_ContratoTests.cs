﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsctxn;
using Bergs.Pxc.Pxcuctxn.Tests;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Bergs.Pxc.Pxcucnxn.Tests
{

    ///  <summary>
    /// Contém os métodos de teste da classe Contrato.
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Contrato.", Author = "B43832")]
    public class ContratoTests : AbstractTesteRegraNegocio<Contrato>
    {
        #region Métodos de preparação dos testes
        private static decimal NUMERO_CONTRATO_VALIDO = 2051997;
        private static string AGENCIA_VALIDA = "2826";
        private static decimal CNPJ_VALIDO = 43977980000190;
        private static DateTime DATA_ASSINATURA_VALIDA = new DateTime(2026, 2, 25);
        private static DateTime DATA_NASCIMENTO_VALIDA = new DateTime(1997, 5, 20);
        private static string NOME_CLIENTE_VALIDO = "Marvin Muller";
        private static string TIPO_IMOVEL_VALIDO = "A";
        private static decimal VALOR_IMOVEL_VALIDO = 200000.00m;

        private static decimal CNPJ_SECUNDARIO = 38091423000137;

        private static decimal NUMERO_CONTRATO_INVALIDO = 20051997;
        private static string AGENCIA_INVALIDA = "282";
        private static decimal CNPJ_INVALIDO = 99977980000190;
        private static string NOME_CLIENTE_INVALIDO = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        private static string TIPO_IMOVEL_INVALIDO = "Y";
        private static decimal VALOR_IMOVEL_INVALIDO = 0.00m;

        private static readonly string TO_NUMERO_CONTRATO = nameof(TOContrato.NumeroContrato);
        private static readonly string TO_AGENCIA = nameof(TOContrato.Agencia);
        private static readonly string TO_CNPJ = nameof(TOContrato.Cnpj);
        private static readonly string TO_DATA_ASSINATURA = nameof(TOContrato.DataAssinatura);
        private static readonly string TO_DATA_NASCIMENTO = nameof(TOContrato.DataNascimento);
        private static readonly string TO_NOME_CLIENTE = nameof(TOContrato.NomeCliente);
        private static readonly string TO_TIPO_IMOVEL = nameof(TOContrato.TipoImovel);
        private static readonly string TO_VALOR_IMOVEL = nameof(TOContrato.ValorImovel);

        private TOContrato CriarToComBlacklist(params string[] blacklist)
        {
            TOContrato toCriado = new TOContrato ();
            
            if (!blacklist.Contains(TO_NUMERO_CONTRATO)) toCriado.NumeroContrato = NUMERO_CONTRATO_VALIDO;
            if (!blacklist.Contains(TO_AGENCIA)) toCriado.Agencia = AGENCIA_VALIDA;
            if (!blacklist.Contains(TO_CNPJ)) toCriado.Cnpj = CNPJ_VALIDO;
            if (!blacklist.Contains(TO_DATA_ASSINATURA)) toCriado.DataAssinatura = DATA_ASSINATURA_VALIDA;
            if (!blacklist.Contains(TO_DATA_NASCIMENTO)) toCriado.DataNascimento = DATA_NASCIMENTO_VALIDA;
            if (!blacklist.Contains(TO_NOME_CLIENTE)) toCriado.NomeCliente = NOME_CLIENTE_VALIDO;
            if (!blacklist.Contains(TO_TIPO_IMOVEL)) toCriado.TipoImovel = TIPO_IMOVEL_VALIDO;
            if (!blacklist.Contains(TO_VALOR_IMOVEL)) toCriado.ValorImovel = VALOR_IMOVEL_VALIDO;

            return toCriado;
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
        {
        }
        ///  <summary>
        /// Executa uma ação ANTES de cada método de teste da classe.
        /// </summary>
        protected override void BeforeEach()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);
            
            this.RN.Incluir(toContrato);
        }
        ///  <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
        /// </summary>
        protected override void AfterAll()
        {
        }
        ///  <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe.
        /// </summary>
        protected override void AfterEach()
        {
        }
        ///  <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build.
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build.</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
        }
        #endregion

        #region US1
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir com sucesso.", Author = "B43832")]
        public void US1_CA01_IncluirComSucessoTest()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);
            
            base.TestarIncluir(toContrato);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem número de contrato.", Author = "B43832")]
        public void US1_CA02_IncluirSemNumeroContrato()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);

            TOContrato toContratoSemNumeroContrato = CriarToComBlacklist(TO_NUMERO_CONTRATO);

            var retorno = this.RN.Incluir(toContratoSemNumeroContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirNumeroContrato);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir com número de contrato inválido.", Author = "B43832")]
        public void US1_CA03_IncluirComNumeroContratoInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();

            toContrato.NumeroContrato = NUMERO_CONTRATO_INVALIDO;

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirNumeroContrato);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem nome cliente.", Author = "B43832")]
        public void US1_CA04_IncluirSemNomeCliente()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_NOME_CLIENTE);

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirNomeCliente);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir com nome cliente inválido.", Author = "B43832")]
        public void US1_CA05_IncluirComNomeClienteInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);

            toContrato.NomeCliente = NOME_CLIENTE_INVALIDO;

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirNomeCliente);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem agência.", Author = "B43832")]
        public void US1_CA06_IncluirSemAgencia()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_AGENCIA);

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirAgencia);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir com agência inválida.", Author = "B43832")]
        public void US1_CA07_IncluirComAgenciaInvalida()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);
            
            toContrato.Agencia = AGENCIA_INVALIDA;

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirAgencia);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem data nascimento.", Author = "B43832")]
        public void US1_CA08_IncluirSemDataNascimento()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_DATA_NASCIMENTO);

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirDataNascimento);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem tipo imóvel.", Author = "B43832")]
        public void US1_CA09_IncluirSemTipoImovel()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_TIPO_IMOVEL);

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirTipoImovel);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir com tipo imóvel inválido.", Author = "B43832")]
        public void US1_CA10_IncluirComTipoImovelInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();

            toContrato.TipoImovel = TIPO_IMOVEL_INVALIDO;

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirTipoImovel);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem valor imóvel.", Author = "B43832")]
        public void US1_CA11_IncluirSemValorImovel()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_VALOR_IMOVEL);

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirValorImovel);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir com valor imóvel inválido.", Author = "B43832")]
        public void US1_CA12_IncluirComValorImovelInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();

            toContrato.ValorImovel = VALOR_IMOVEL_INVALIDO;

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirValorImovel);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir sem CNPJ.", Author = "B43832")]
        public void US1_CA13_IncluirSemCnpj()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_CNPJ);

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirCNPJ);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir com CNPJ inválido.", Author = "B43832")]
        public void US1_CA14_IncluirComCnpjInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_CNPJ);

            toContrato.Cnpj = CNPJ_INVALIDO;

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = TOContrato.CNPJ_INVALIDO;
            MMAssert.True(retorno.Mensagem.ParaUsuario.ToString().Contains(mensagem));
        }
        /// <summary></summary>
        [Test(Description = "Testa o método Incluir registro duplicado", Author = "B43832")]
        public void US1_CA15_IncluirRegistroDuplicado()
        {
            TOContrato toContrato = CriarToComBlacklist();
            
            this.RN.Excluir(toContrato);
            
            this.RN.Incluir(toContrato);

            var retorno = this.RN.Incluir(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaIncluirRegistroDuplicado);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        #endregion

        #region US2
        ///  <summary></summary>
        [Test(Description = "Testa o método listar sem filtro com sucesso.", Author = "B43832")]
        public void US2_CA01_ListarSemFiltroComSucessoTest()
        {
            TOContrato toContrato = new TOContrato();
            
            base.TestarListar(toContrato, null);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método listar com filtro com sucesso.", Author = "B43832")]
        public void US2_CA02_ListarComFiltroComSucessoTest()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_NOME_CLIENTE, TO_DATA_ASSINATURA);
            
            base.TestarListar(toContrato, null);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método listar com tipo imóvel inválido.", Author = "B43832")]
        public void US2_CA03_ListarComTipoImovelInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_NOME_CLIENTE, TO_DATA_ASSINATURA);
            toContrato.TipoImovel = TIPO_IMOVEL_INVALIDO;
            
            var retorno = this.RN.Listar(toContrato, null);

            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaListarTipoImovel);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método listar com nome cliente inválido.", Author = "B43832")]
        public void US2_CA04_ListarComNomeClienteInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_TIPO_IMOVEL, TO_DATA_ASSINATURA);
            toContrato.NomeCliente = NOME_CLIENTE_INVALIDO;

            var retorno = this.RN.Listar(toContrato, null);

            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaListarNomeCliente);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método listar sem filtro sem registros.", Author = "B43832")]
        public void US2_CA05_ListarComFiltroSemRegistro()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);
            
            var retorno = this.RN.Listar(toContrato, null);

            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaListarRegistroInexistente);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        #endregion

        #region US3
        ///  <summary></summary>
        [Test(Description = "Testa o método obter com sucesso.", Author = "B43832")]
        public void US3_CA01_ObterComSucesso()
        {
            TOContrato toContrato = CriarToComBlacklist();

            base.TestarObter(toContrato);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método obter sem número contrato.", Author = "B43832")]
        public void US3_CA02_ObterSemNumeroContrato()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_NUMERO_CONTRATO);

            var retorno = this.RN.Obter(toContrato);

            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaObterNumeroContrato);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método obter com número contrato inválido.", Author = "B43832")]
        public void US3_CA03_ObterComNumeroContratoInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();
            toContrato.NumeroContrato = NUMERO_CONTRATO_INVALIDO;

            var retorno = this.RN.Obter(toContrato);

            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaObterNumeroContrato);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método obter sem registro.", Author = "B43832")]
        public void US3_CA04_ObterSemRegistro()
        {
            TOContrato toContrato = CriarToComBlacklist();

            this.RN.Excluir(toContrato);

            var retorno = this.RN.Obter(toContrato);

            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaObterRegistroInexistente);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        #endregion

        #region US4
        ///  <summary></summary>
        [Test(Description = "Testa o método alterar com sucesso.", Author = "B43832")]
        public void US4_CA01_AlterarComSucesso()
        {
            TOContrato toContrato = CriarToComBlacklist();
            toContrato.Cnpj = CNPJ_SECUNDARIO;

            base.TestarAlterar(toContrato);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método alterar sem número contrato.", Author = "B43832")]
        public void US4_CA02_AlterarSemNumeroContrato()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_NUMERO_CONTRATO);

            var retorno = this.RN.Alterar(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaAlterarNumeroContrato);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método alterar com número contrato inválido.", Author = "B43832")]
        public void US4_CA03_AlterarComNumeroContratoInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();
            toContrato.NumeroContrato = NUMERO_CONTRATO_INVALIDO;

            var retorno = this.RN.Alterar(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaAlterarNumeroContrato);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método alterar sem cnpj.", Author = "B43832")]
        public void US4_CA04_AlterarSemCnpj()
        {
            TOContrato toContrato = CriarToComBlacklist(TO_CNPJ);

            var retorno = this.RN.Alterar(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaAlterarCNPJ);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método alterar com cnpj inválido.", Author = "B43832")]
        public void US4_CA05_AlterarComCnpjInvalido()
        {
            TOContrato toContrato = CriarToComBlacklist();
            toContrato.Cnpj = CNPJ_INVALIDO;

            var retorno = this.RN.Alterar(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = TOContrato.CNPJ_INVALIDO;
            MMAssert.True(retorno.Mensagem.ParaUsuario.ToString().Contains(mensagem));
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método alterar sem registro.", Author = "B43832")]
        public void US4_CA06_AlterarSemRegistro()
        {
            var mock = new MockContrato(this.Infra);
            mock.AlterarComFalha();

            TOContrato toContrato = CriarToComBlacklist();

            var retorno = this.RN.Alterar(toContrato);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            var mensagem = new Mensagem(TipoMensagem.FalhaAlterarRegistroInexistente);
            MMAssert.FalhaComMensagem<Mensagem>(retorno, mensagem.Identificador);
        }
        #endregion
    }
}


﻿using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.IN;
using Bergs.Pwx.Pwxoiexn.IN.Controles;
using Bergs.Pxc.Pxcbtoxn;
using System;
using System.Collections.Generic;
using System.Web.Services;

namespace Bergs.Pxc.Pxcwctxn
{
	
	/// <summary>Classe responsável pela tela da transação.</summary>
	[WebService(Namespace = "Bergs.Pxc.Pxcwctxn")]
	[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
	public class Contrato : AplicacaoTelaHtml5
	{
		/// <summary>Construtor.</summary>
		public Contrato() : 
				base(10)
		{
		}
		/// <summary>Pesquisa dados referentes ao filtro aplicado</summary>
		/// <param name="pagina">Pagina inicial.</param>
		/// <returns>Lista dos dados obtidos.</returns>
		[WebMethod()]
		protected override string Listar(Int32 pagina)
		{
			try
			{
				Pxcsctxn.Contrato rnContrato = this.Infra.InstanciarRN<Pxcsctxn.Contrato>();
				TOContrato toContrato = this.PopularTOContratoFiltro();
				Retorno<long> contagemContrato = rnContrato.Contar(toContrato);
				if (!(contagemContrato.OK && contagemContrato.Dados > 0))
				{
					return this.Infra.RetornarJson(contagemContrato);
				}
				this.CalcularPaginacao(contagemContrato.Dados);
				TOPaginacao toPaginacao = new TOPaginacao(this.Pagina, this.RegistrosPorPagina);
				Retorno<List<TOContrato>> retorno = rnContrato.Listar(toContrato, toPaginacao);
				ListaHtml5<TOContrato> lista = new ListaHtml5<TOContrato>(retorno.Dados, toPaginacao);
				return this.Infra.RetornarJson(retorno, lista);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Inclui um registro.</summary>
		/// <returns>Status da operação</returns>
		[WebMethod()]
		public string Incluir()
		{
			try
			{
				TOContrato toContrato = this.PopularTOContratoCadastro();
				Pxcsctxn.Contrato rnContrato = this.Infra.InstanciarRN<Pxcsctxn.Contrato>();
				Retorno<int> retorno = rnContrato.Incluir(toContrato);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Salva alterações do item detalhado</summary>
		/// <returns>Status da operação.</returns>
		[WebMethod()]
		public string Alterar()
		{
			try
			{
				TOContrato toContrato = this.PopularTOContratoCadastro();
				Pxcsctxn.Contrato rnContrato = this.Infra.InstanciarRN<Pxcsctxn.Contrato>();
				Retorno<int> retorno = rnContrato.Alterar(toContrato);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Exclui o item detalhado.</summary>
		/// <returns>Status da operação.</returns>
		[WebMethod()]
		public string Excluir()
		{
			try
			{
				TOContrato toContrato = this.PopularTOContratoCadastro();
				Pxcsctxn.Contrato rnContrato = this.Infra.InstanciarRN<Pxcsctxn.Contrato>();
				Retorno<int> retorno = rnContrato.Excluir(toContrato);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Obtém o objeto pela chave.</summary>
		/// <returns>Objeto</returns>
		[WebMethod()]
		public string Obter()
		{
			try
			{
				TOContrato toContrato = this.PopularTOContratoLista();
				Pxcsctxn.Contrato rnContrato = this.Infra.InstanciarRN<Pxcsctxn.Contrato>();
				Retorno<TOContrato> retorno = rnContrato.Obter(toContrato);
				return this.Infra.RetornarJson(retorno);
			}
			catch (Exception ex)
			{
				return this.Infra.TratarExcecaoJson(ex);
			}
		}
		/// <summary>Popula um TOContrato para ser utilizado nos métodos de Filtro.</summary>
		/// <returns>TO populado</returns>
		private TOContrato PopularTOContratoFiltro()
		{
			TOContrato toContrato = new TOContrato();

            if (this.LerValorCliente("data_assinatura") != null)
            {
                toContrato.DataAssinatura = Convert.ToDateTime(this.LerValorCliente("data_assinatura"));
            }
            if (this.LerValorCliente("tipo_imovel") != null)
            {
                toContrato.TipoImovel = this.LerValorCliente("tipo_imovel");
            }
            if (this.LerValorCliente("nome_cliente") != null)
            {
                toContrato.NomeCliente = this.LerValorCliente("nome_cliente");
            }
            return toContrato;
		}
		/// <summary>Popula um TOContrato para ser utilizado nos métodos de Cadastro.</summary>
		/// <returns>TO populado</returns>
		private TOContrato PopularTOContratoCadastro()
		{
			TOContrato toContrato = new TOContrato();
			if (this.LerValorCliente("numero_contrato") != null)
			{
				toContrato.NumeroContrato = Convert.ToDecimal(this.LerValorCliente("numero_contrato"));
			}
			if (this.LerValorCliente("data_assinatura") != null)
			{
				toContrato.DataAssinatura = Convert.ToDateTime(this.LerValorCliente("data_assinatura"));
			}
			if (this.LerValorCliente("nome_cliente") != null)
			{
				toContrato.NomeCliente = this.LerValorCliente("nome_cliente");
			}
			if (this.LerValorCliente("agencia") != null)
			{
				toContrato.Agencia = Convert.ToString(this.LerValorCliente("agencia"));
			}
			if (this.LerValorCliente("data_nascimento") != null)
			{
				toContrato.DataNascimento = Convert.ToDateTime(this.LerValorCliente("data_nascimento"));
			}
            if (this.LerValorCliente("tipo_imovel") != null)
            {
                toContrato.TipoImovel = this.LerValorCliente("tipo_imovel");
            }
            if (this.LerValorCliente("valor_imovel") != null)
			{
				toContrato.ValorImovel = Convert.ToDecimal(this.LerValorCliente("valor_imovel"));
			}
			else
			{
				toContrato.ValorImovel = new CampoOpcional<decimal>(null);
			}
			if (this.LerValorCliente("cnpj") != null)
			{
				toContrato.Cnpj = Convert.ToDecimal(this.LerValorCliente("cnpj"));
			}
			return toContrato;
		}
		/// <summary>Popula um TOContrato para ser utilizado nos métodos de Cadastro.</summary>
		/// <returns>TO populado</returns>
		private TOContrato PopularTOContratoLista()
		{
			TOContrato toContrato = new TOContrato();
			if (this.LerValorCliente("numero_contrato") != null)
			{
				toContrato.NumeroContrato = Convert.ToDecimal(this.LerValorCliente("numero_contrato"));
            }
            if (this.LerValorCliente("data_assinatura") != null)
            {
                toContrato.DataAssinatura = Convert.ToDateTime(this.LerValorCliente("data_assinatura"));
            }
            if (this.LerValorCliente("tipo_imovel") != null)
            {
                toContrato.TipoImovel = this.LerValorCliente("data_nascimento");
            }
            if (this.LerValorCliente("nome_cliente") != null)
            {
                toContrato.NomeCliente = this.LerValorCliente("nome_cliente");
            }
            if (this.LerValorCliente("ult_atualizacao") != null)
			{
				toContrato.UltAtualizacao = Convert.ToDateTime(this.LerValorCliente("ult_atualizacao"));
			}
			return toContrato;
		}
	}
}


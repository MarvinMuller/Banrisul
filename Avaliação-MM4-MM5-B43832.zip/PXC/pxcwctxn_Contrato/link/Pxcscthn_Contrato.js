﻿/// <reference path="c:\soft\pwx\link\pwxscohn_jquery_html5.js" />
'use strict';
function Pxcscthn() { }

Pxcscthn.prototype = {
    load: function () {

        $('#btnPesquisarFiltro').click(this.clicarPesquisar);
        $('#btnNovoFiltro').click(this.clicarNovo);
        $('#btnLimparFiltroFiltro').click( function () { oInfra.getTela().limparCamposAtivosFormulario('#boxDadosFiltro'); });
        $('#btnNovoLista').click(this.clicarNovo);
        $('#btnVoltarLista').click(function () { oInfra.getTela().clicarBotaoVoltar(); });
        $('#btnNovoCadastro').click(this.clicarNovo);
        $('#btnIncluirCadastro').click(this.clicarIncluir);
        $('#btnSalvarCadastro').click(this.clicarSalvar);
        $('#btnHabilitarCadastro').click(function () { oInfra.getTela().clicarHabilitarCadastro(); });
        $('#btnExcluirCadastro').click(this.clicarExcluir);
        $('#btnLimparCadastroCadastro').click( function () { oInfra.getTela().limparCamposAtivosFormulario('#boxDadosCadastro'); });
        $('#btnVoltarCadastro').click(function () { oInfra.getTela().clicarBotaoVoltar(); });
        oInfra.getUtil().carregarValidador();
    },
    formatarLinhaListaTabelalista: function (dados) {
        dados.numero_contrato_formatado = oInfra.getUtil().aplicarMascara(dados.numero_contrato, '9999999');
        dados.data_assinatura_formatado = oInfra.getUtil().aplicarMascara(dados.data_assinatura, '00/00/0000');
        dados.data_nascimento_formatado = oInfra.getUtil().aplicarMascara(dados.data_nascimento, '00/00/0000');
        let tipos = { A: "Apartamento", C: "Casa", T: "Terreno", P: "Ponto" };
        dados.tipo_imovel_formatado = tipos[dados.tipo_imovel] || "";
        dados.valor_imovel_formatado = oInfra.getUtil().aplicarMascara(dados.valor_imovel, '9999999999999.00');
        dados.cnpj_formatado = oInfra.getUtil().aplicarMascara(dados.cnpj, '000.000.000/0000-00');
        dados.ult_atualizacao_formatado = oInfra.getUtil().aplicarMascara(dados.ult_atualizacao, '00/00/0000 00:00:00');
        return dados;
    },
    clicarPesquisar: function () {
        if (!oInfra.getUtil().validarFormulario('#formFiltro')) {
            return false;
        }

        oInfra.getTela().getParametros().limpar();
        var parms = oInfra.getTransacao().getParametros().oPares;
        parms.data_assinatura = $('#txtFiltroDataAssinatura').val().trim();
        var tipo_imovel = oInfra.getUtil().getSelecionadosCombo('cboFiltroTipoImovel');
        parms.tipo_imovel = tipo_imovel ? tipo_imovel[0] : '';
        parms.nome_cliente = $('#txtFiltroNomeCliente').val().trim();

        oInfra.getTela().clicarBotaoPrimeiraPagina();
    },
    clicarNovo: function () {
        oInfra.getTela().limparCamposFormulario('#formCadastro');
        oInfra.getTela().mostrarTela('Cadastro', 'Inclusao');

    },
    clicarIncluir: function () {
        if (!oInfra.getUtil().validarFormulario('#formCadastro')) {
            return false;
        }

        oInfra.getTela().getParametros().limpar();
        var parms = oInfra.getTela().getParametros().oPares;
        parms.numero_contrato = $('#txtCadastroNumeroContrato').val().trim();
        parms.data_assinatura = $('#txtCadastroDataAssinatura').val().trim();
        parms.nome_cliente = $('#txtCadastroNomeCliente').val().trim();
        parms.agencia = $('#txtCadastroAgencia').val().trim();
        parms.data_nascimento = $('#txtCadastroDataNascimento').val().trim();
        var tipo_imovel = oInfra.getUtil().getSelecionadosCombo('cboCadastroTipoImovel');
        parms.tipo_imovel = tipo_imovel ? tipo_imovel[0] : '';
        parms.valor_imovel = oInfra.getUtil().obterValorSemMascara('#txtCadastroValorImovel');
        parms.cnpj = oInfra.getUtil().obterValorSemMascara('#txtCadastroCnpj');

        oInfra.getServidor().invocarServico('Pxcwctxn_Contrato.asmx/Incluir', {parametros: parms });
    },
    clicarSalvar: function () {
        if (!oInfra.getUtil().validarFormulario('#formCadastro')) {
            return false;
        }

        oInfra.getTela().getParametros().limpar();
        var parms = oInfra.getTela().getParametros().oPares;
        parms.numero_contrato = $('#txtCadastroNumeroContrato').val().trim();
        
        parms.cnpj = oInfra.getUtil().obterValorSemMascara('#txtCadastroCnpj');

        oInfra.getServidor().invocarServico('Pxcwctxn_Contrato.asmx/Alterar', {parametros: parms });
    },
    clicarExcluir: function () {
        oInfra.getTela().mensagem(
            'Confirma a exclusão do registro?',
            'Atenção',
            ['Sim', 'Não'],
            [
                function () {
                    oInfra.getTela().fecharMensagem();
                    var numero_contrato = $('#txtCadastroNumeroContrato').val().trim();
                    oInfra.getTela().getParametros().limpar();
                    var parms = oInfra.getTela().getParametros().oPares;
                    parms.numero_contrato = numero_contrato;
                    oInfra.getServidor().invocarServico('Pxcwctxn_Contrato.asmx/Excluir', { parametros: parms});
                },
                function () {
                    oInfra.getTela().fecharMensagem();
                }
            ]
        );
    },
    tratarRetornoObterboxDadosCadastro: function (oJson) {
        if (oInfra.getJsonUtil().confirmarSucesso(oJson)) {
            if (oJson.dados) {
                oInfra.getTela().popularCamposFormulario('#formCadastro', {
                    numero_contrato: oJson.dados.registrousuario.numero_contrato,
                    data_assinatura: oJson.dados.registrousuario.data_assinatura,
                    nome_cliente: oJson.dados.registrousuario.nome_cliente,
                    agencia: oJson.dados.registrousuario.agencia,
                    data_nascimento: oJson.dados.registrousuario.data_nascimento,
                    tipo_imovel: oJson.dados.registrousuario.tipo_imovel,
                    valor_imovel: oJson.dados.registrousuario.valor_imovel,
                    cnpj: oJson.dados.registrousuario.cnpj
                });

                oInfra.getTela().mostrarTela('Cadastro', 'Consulta');
            }
        } else {
            oInfra.getTela().mensagem(oInfra.getJsonUtil().lerMensagem(oJson));
        }
    },
    exibirContrato: function (numero_contrato) {
        oInfra.getTela().getParametros().limpar();
        var parms = oInfra.getTela().getParametros().oPares;
        parms.numero_contrato = numero_contrato;
        oInfra.getServidor().invocarServico('Pxcwctxn_Contrato.asmx/Obter', {
            parametros: parms,
            retorno: oPxcscthn.tratarRetornoObterboxDadosCadastro
        });
    },

};
